Product: Geneva Stop, September 2014

Designer: Zombie Cat, http://zombie-cat.org/

Support:  http://forums.obrary.com/category/designs/geneva-stop

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
The Geneva Stop is a teaching tool designed to give students hands-on experience understanding how the mechanism works. The Geneva Stop would be considered a more advanced mechanism for building projects and is not introduced to students building basic automata.